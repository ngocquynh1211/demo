#!/bin/sh

cat 1>&2 <<EOF
Unable to read consumer identity
Unable to read consumer identity
EOF

cat <<EOF
ftp.x86_64
mlocate.x86_64
python-mako.noarch
python-zope-interface.x86_64
wget.x86_64
Obsoleting
python-zope-interface.x86_64
EOF

